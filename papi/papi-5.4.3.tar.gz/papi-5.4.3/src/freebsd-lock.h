
#define _papi_hwd_lock(a) { ; }
#define _papi_hwd_unlock(a) { ; }

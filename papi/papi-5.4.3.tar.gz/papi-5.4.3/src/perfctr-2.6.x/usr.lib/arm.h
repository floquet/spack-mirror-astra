/* $Id: arm.h,v 1.1.2.1 2007/02/11 20:15:03 mikpe Exp $
 * ARM-specific code for performance counters library.
 *
 * Copyright (C) 2005-2007  Mikael Pettersson
 */
#ifndef __LIB_PERFCTR_ARM_H
#define __LIB_PERFCTR_ARM_H

#define PAGE_SIZE	4096

#define perfctr_info_cpu_init(info)	do{}while(0)

#endif /* __LIB_PERFCTR_ARM_H */

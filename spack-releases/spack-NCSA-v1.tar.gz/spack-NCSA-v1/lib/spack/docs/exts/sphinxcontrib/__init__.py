# -*- coding: utf-8 -*-
"""
    sphinxcontrib
    ~~~~~~~~~~~~~

    Contains 3rd party Sphinx extensions.
"""

__import__('pkg_resources').declare_namespace(__name__)

#!/usr/bin/env bash
export NEW_VAR='new'
export UNSET_ME='overridden'

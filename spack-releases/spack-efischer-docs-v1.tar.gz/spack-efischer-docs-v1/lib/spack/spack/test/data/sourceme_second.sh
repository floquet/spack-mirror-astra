#!/usr/bin/env bash
export PATH_LIST='/path/first:/path/second:/path/fourth'
unset EMPTY_PATH_LIST